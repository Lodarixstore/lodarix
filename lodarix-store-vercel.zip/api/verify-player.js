// Vercel Serverless Function — verificar ID de Free Fire
// Variable de entorno requerida: FREEFIRE_API_KEY

module.exports = async function handler(req, res) {
  // CORS
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");
  res.setHeader("Cache-Control", "no-store");

  if (req.method === "OPTIONS") {
    return res.status(204).end();
  }

  if (req.method !== "POST") {
    return res.status(405).json({ success: false, error: "Método no permitido." });
  }

  try {
    const body = typeof req.body === "string" ? JSON.parse(req.body || "{}") : (req.body || {});
    const uid = String(body.uid || "").trim();

    if (!/^\d{5,15}$/.test(uid)) {
      return res.status(400).json({
        success: false,
        error: "El ID de Free Fire no es válido."
      });
    }

    const apiKey = process.env.FREEFIRE_API_KEY;

    if (!apiKey) {
      console.error("Missing FREEFIRE_API_KEY environment variable.");
      return res.status(500).json({
        success: false,
        error: "La API de Free Fire no está configurada en Vercel."
      });
    }

    const params = new URLSearchParams({
      uid,
      region: "SAC",
      key: apiKey.trim()
    });

    const url = `http://siambhau69.eu.cc/freefireinfo/bhau?${params.toString()}`;

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 15000);

    let response;
    let raw = "";

    try {
      response = await fetch(url, {
        method: "GET",
        headers: {
          Accept: "application/json",
          "User-Agent": "Lodarix/1.0"
        },
        signal: controller.signal
      });
      raw = await response.text();
    } finally {
      clearTimeout(timeout);
    }

    let data = {};
    try {
      data = JSON.parse(raw);
    } catch (_) {
      console.error("FreeFireApi returned non-JSON:", response.status, raw.slice(0, 1000));
    }

    if (!response.ok) {
      console.error("FreeFireApi error:", response.status, raw.slice(0, 1500));

      const apiError = data.error || data.message || data.detail || "";

      if (response.status === 403) {
        return res.status(502).json({
          success: false,
          error: apiError || "La API rechazó la clave o no tiene acceso al endpoint."
        });
      }

      if (response.status === 404) {
        return res.status(404).json({
          success: false,
          error: apiError || "No se encontró el jugador. Comprueba el ID."
        });
      }

      if (response.status >= 500) {
        return res.status(502).json({
          success: false,
          error: "El servicio de consulta de Free Fire está temporalmente no disponible."
        });
      }

      return res.status(502).json({
        success: false,
        error: apiError || `La API respondió con HTTP ${response.status}.`
      });
    }

    const account = data.basicInfo || data.BasicInfo || data.accountInfo || {};
    const name =
      account.nickname ||
      account.nickName ||
      account.AccountName ||
      data.nickname ||
      data.name ||
      "";

    const region =
      account.region ||
      account.AccountRegion ||
      data.region ||
      "SAC";

    const level =
      account.level ??
      account.AccountLevel ??
      data.level ??
      null;

    if (!name) {
      console.error("FreeFireApi response did not contain nickname:", raw.slice(0, 2500));
      return res.status(404).json({
        success: false,
        error: "El ID fue consultado, pero no se encontró el nombre del jugador."
      });
    }

    return res.status(200).json({
      success: true,
      uid,
      name,
      region,
      level
    });
  } catch (error) {
    console.error("verify-player error:", error);

    if (error && error.name === "AbortError") {
      return res.status(504).json({
        success: false,
        error: "La verificación tardó demasiado. Inténtalo nuevamente."
      });
    }

    return res.status(500).json({
      success: false,
      error: "Ocurrió un error al verificar el jugador. Inténtalo nuevamente."
    });
  }
};
